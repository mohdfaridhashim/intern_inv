<?php namespace ProcessWire;
if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "inventory", 
	'summary' => "", 
	'screenshot' => ""
);
