<?php namespace ProcessWire;

// Template file for “home” template used by the homepage

?>

<div id="content">
	Homepage content 
</div>	
	
