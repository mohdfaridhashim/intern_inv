<?php namespace ProcessWire; 

// Template file for pages using the “basic-page” template

?>


<div id="content">
	Basic page content 
</div>	

